# BabyMonitor > 2024-11-17 1:33am
https://universe.roboflow.com/ml-projects-osdwj/babymonitor-aatlu

Provided by a Roboflow user
License: CC BY 4.0

